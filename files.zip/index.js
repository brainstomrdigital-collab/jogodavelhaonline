require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const authRoutes = require('./routes/auth');
const paymentRoutes = require('./routes/payment');
const { setupGameSocket } = require('./game/manager');
const { UserService } = require('./db');
const authMiddleware = require('./middleware/auth');

const app = express();
const server = http.createServer(app);

const FRONTEND_URL = process.env.FRONTEND_URL || '*';

const io = new Server(server, {
  cors: {
    origin: FRONTEND_URL,
    methods: ['GET', 'POST'],
    credentials: true,
  }
});

// Middlewares
app.use(cors({ origin: FRONTEND_URL, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Rate limit global
app.use(rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  message: { error: 'Muitas requisições. Aguarde um momento.' }
}));

// Segurança: remover headers que revelam tecnologia
app.disable('x-powered-by');

// Rotas
app.use('/api/auth', authRoutes);
app.use('/api/payment', paymentRoutes);

// Rota de status
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Perfil do usuário
app.get('/api/user/profile', authMiddleware, (req, res) => {
  const user = UserService.findById(req.user.id);
  res.json({ user: UserService.safePublic(user) });
});

// Leaderboard
app.get('/api/leaderboard', (req, res) => {
  // Em produção: query no banco ordenando por wins
  res.json({ message: 'Em breve' });
});

// Setup WebSocket do jogo
setupGameSocket(io);

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`🚀 TicTacBet server rodando na porta ${PORT}`);
  console.log(`🌍 Frontend URL: ${FRONTEND_URL}`);
  console.log(`💰 Rake: ${process.env.RAKE_PERCENT || 10}%`);
});

module.exports = { app, server };
