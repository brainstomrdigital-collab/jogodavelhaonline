// game/manager.js - Gerenciador de partidas e matchmaking
const jwt = require('jsonwebtoken');
const { GameRoom } = require('./engine');
const { UserService } = require('../db');

const activeGames = new Map();     // gameId -> GameRoom
const waitingPlayers = new Map();  // bet -> { user, socketId }
const playerGame = new Map();      // userId -> gameId

function setupGameSocket(io) {
  // Autenticar socket via JWT
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('Token não fornecido'));
    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);
      const user = UserService.findById(payload.userId);
      if (!user || user.banned) return next(new Error('Usuário inválido'));
      socket.user = user;
      next();
    } catch {
      next(new Error('Token inválido'));
    }
  });

  io.on('connection', (socket) => {
    const user = socket.user;
    console.log(`🔌 Conectado: ${user.nick} (${socket.id})`);

    // Reconectar a jogo em andamento
    const existingGameId = playerGame.get(user.id);
    if (existingGameId) {
      const game = activeGames.get(existingGameId);
      if (game && game.status === 'playing') {
        socket.join(existingGameId);
        socket.emit('game:reconnected', game.toPublic());
      }
    }

    // Entrar na fila de matchmaking
    socket.on('game:queue', ({ bet }) => {
      bet = parseInt(bet);
      const MIN_BET = parseInt(process.env.MIN_BET || 10);
      const MAX_BET = parseInt(process.env.MAX_BET || 10000);

      if (!bet || bet < MIN_BET || bet > MAX_BET) {
        return socket.emit('error', { message: `Aposta inválida (min: ${MIN_BET}, max: ${MAX_BET} fichas)` });
      }

      const freshUser = UserService.findById(user.id);
      if (!freshUser || freshUser.balance < bet) {
        return socket.emit('error', { message: 'Saldo insuficiente para esta aposta' });
      }

      // Sair de jogo anterior se houver
      if (playerGame.has(user.id)) {
        return socket.emit('error', { message: 'Você já está em uma partida' });
      }

      socket.emit('game:queued', { bet, message: 'Procurando oponente...' });

      // Verificar se há alguém esperando com a mesma aposta
      const betKey = bet.toString();
      const waiting = waitingPlayers.get(betKey);

      if (waiting && waiting.userId !== user.id) {
        // Match encontrado!
        waitingPlayers.delete(betKey);
        const opponent = UserService.findById(waiting.userId);
        if (!opponent) {
          // Oponente saiu, colocar na fila
          waitingPlayers.set(betKey, { userId: user.id, socketId: socket.id, nick: user.nick });
          return;
        }

        startGame(io, socket, waiting.socketId, user, opponent, bet, false);
      } else {
        // Entrar na fila
        waitingPlayers.set(betKey, { userId: user.id, socketId: socket.id, nick: user.nick });

        // Se não encontrar oponente em 8 segundos, criar jogo com bot
        setTimeout(() => {
          if (waitingPlayers.get(betKey)?.userId === user.id) {
            waitingPlayers.delete(betKey);
            const bot = UserService.getRandomBot();
            startGame(io, socket, null, user, bot, bet, true);
          }
        }, 8000);
      }
    });

    // Realizar jogada
    socket.on('game:move', ({ gameId, position }) => {
      const game = activeGames.get(gameId);
      if (!game) return socket.emit('error', { message: 'Jogo não encontrado' });
      if (game.player1.id !== user.id && game.player2.id !== user.id) {
        return socket.emit('error', { message: 'Você não está neste jogo' });
      }

      const result = game.makeMove(user.id, position);
      if (result.error) return socket.emit('error', { message: result.error });

      // Atualizar saldo na resposta
      const freshUser = UserService.findById(user.id);
      io.to(gameId).emit('game:update', {
        ...game.toPublic(),
        lastMove: position,
      });

      if (game.status === 'finished') {
        io.to(gameId).emit('game:over', {
          winner: game.winner,
          winCombo: game.winCombo,
          game: game.toPublic(),
        });
        playerGame.delete(game.player1.id);
        playerGame.delete(game.player2.id);
        setTimeout(() => activeGames.delete(gameId), 60000);
      } else if (game.isBot && game.currentTurn === game.player2.id) {
        // Turno do bot - responder após delay para parecer humano
        setTimeout(() => {
          const botPos = game.getBotMovePosition();
          const botResult = game.makeMove(game.player2.id, botPos);

          io.to(gameId).emit('game:update', {
            ...game.toPublic(),
            lastMove: botPos,
            botMove: true,
          });

          if (game.status === 'finished') {
            io.to(gameId).emit('game:over', {
              winner: game.winner,
              winCombo: game.winCombo,
              game: game.toPublic(),
            });
            playerGame.delete(game.player1.id);
            setTimeout(() => activeGames.delete(gameId), 60000);
          }
        }, 800 + Math.random() * 1200);
      }
    });

    // Desistir da partida
    socket.on('game:forfeit', ({ gameId }) => {
      const game = activeGames.get(gameId);
      if (!game || game.status !== 'playing') return;

      const isP1 = game.player1.id === user.id;
      const winnerId = isP1 ? game.player2.id : game.player1.id;

      game.makeMove(user.id, -1); // força encerramento via forfeit
      game.status = 'finished';
      game.winner = winnerId;
      game._settleWin(winnerId, user.id);

      io.to(gameId).emit('game:over', {
        winner: winnerId,
        forfeit: true,
        game: game.toPublic(),
      });

      playerGame.delete(game.player1.id);
      playerGame.delete(game.player2.id);
    });

    // Sair da fila
    socket.on('game:dequeue', () => {
      waitingPlayers.forEach((val, key) => {
        if (val.userId === user.id) waitingPlayers.delete(key);
      });
      socket.emit('game:dequeued');
    });

    socket.on('disconnect', () => {
      console.log(`🔌 Desconectado: ${user.nick}`);
      // Remover da fila se estiver aguardando
      waitingPlayers.forEach((val, key) => {
        if (val.userId === user.id) waitingPlayers.delete(key);
      });
    });
  });
}

function startGame(io, socket1, socket2Id, player1, player2, bet, isBot) {
  const game = new GameRoom({ player1, player2, bet, isBot });
  activeGames.set(game.id, game);
  playerGame.set(player1.id, game.id);
  if (!isBot) playerGame.set(player2.id, game.id);

  socket1.join(game.id);
  if (!isBot && socket2Id) {
    const socket2 = io.sockets.sockets.get(socket2Id);
    if (socket2) socket2.join(game.id);
  }

  io.to(game.id).emit('game:start', game.toPublic());
  console.log(`🎮 Game iniciado: ${game.id} | ${player1.nick} vs ${player2.nick} | ${bet} fichas`);
}

module.exports = { setupGameSocket };
