const express = require('express');
const axios = require('axios');
const rateLimit = require('express-rate-limit');
const authMiddleware = require('../middleware/auth');
const { UserService, TransactionService, DepositService } = require('../db');

const router = express.Router();

const ABACATEPAY_BASE = 'https://api.abacatepay.com/v1';
const RAKE = parseInt(process.env.RAKE_PERCENT || 10);
const MIN_BET = parseInt(process.env.MIN_BET || 10);
const MAX_BET = parseInt(process.env.MAX_BET || 10000);
const MIN_WITHDRAW = parseInt(process.env.MIN_WITHDRAW || 500);
const WITHDRAW_FEE = parseInt(process.env.WITHDRAW_FEE_PERCENT || 5);

// Fichas: 1 ficha = R$0,10  (100 fichas = R$10,00)
const FICHAS_PER_REAL = 10;

function fichasToReais(fichas) {
  return (fichas / FICHAS_PER_REAL).toFixed(2);
}

function reaisToFichas(reais) {
  return Math.floor(reais * FICHAS_PER_REAL);
}

async function abacateRequest(method, endpoint, data = null) {
  const config = {
    method,
    url: `${ABACATEPAY_BASE}${endpoint}`,
    headers: {
      'Authorization': `Bearer ${process.env.ABACATEPAY_API_KEY}`,
      'Content-Type': 'application/json',
    }
  };
  if (data) config.data = data;
  const res = await axios(config);
  return res.data;
}

// POST /api/payment/deposit - Gerar QR Code Pix para depósito
router.post('/deposit', authMiddleware, rateLimit({ windowMs: 60000, max: 5 }), async (req, res) => {
  try {
    const { amount } = req.body; // amount em fichas
    const user = req.user;

    if (!amount || amount < MIN_BET) {
      return res.status(400).json({ error: `Depósito mínimo: ${MIN_BET} fichas (R$${fichasToReais(MIN_BET)})` });
    }

    if (amount > MAX_BET * 10) {
      return res.status(400).json({ error: 'Valor acima do limite permitido' });
    }

    const valorReais = parseFloat(fichasToReais(amount));
    const valorCentavos = Math.round(valorReais * 100);

    // Criar cobrança na Abacatepay
    const pixData = await abacateRequest('POST', '/pixQrCode/create', {
      amount: valorCentavos,
      expiresIn: 1800, // 30 minutos
      customer: {
        name: user.nick,
        email: user.email,
        taxId: { type: 'CPF', number: user.cpf || '00000000000' }
      },
      description: `Depósito TicTacBet - ${amount} fichas`,
      metadata: {
        userId: user.id,
        fichas: amount
      }
    });

    const deposit = DepositService.create(user.id, amount, pixData.data);

    res.json({
      depositId: deposit.id,
      qrCode: pixData.data.brCode,
      qrCodeBase64: pixData.data.brCodeBase64,
      amount,
      amountReais: valorReais,
      expiresAt: pixData.data.expiresAt,
    });
  } catch (err) {
    console.error('Deposit error:', err?.response?.data || err.message);
    res.status(500).json({ error: 'Erro ao gerar Pix. Tente novamente.' });
  }
});

// POST /api/payment/webhook - Confirmação de pagamento da Abacatepay
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    // Verificar assinatura do webhook (segurança crítica)
    const signature = req.headers['x-abacatepay-signature'];
    const webhookSecret = process.env.ABACATEPAY_WEBHOOK_SECRET;

    if (webhookSecret && signature) {
      const crypto = require('crypto');
      const expectedSig = crypto
        .createHmac('sha256', webhookSecret)
        .update(req.body)
        .digest('hex');
      if (signature !== expectedSig) {
        console.warn('Webhook signature inválida!');
        return res.status(401).json({ error: 'Assinatura inválida' });
      }
    }

    const body = JSON.parse(req.body.toString());
    const { event, data } = body;

    if (event === 'PAYMENT_CONFIRMED' || event === 'pixQrCode.paid') {
      const pixId = data?.id;
      if (!pixId) return res.status(400).json({ error: 'ID não encontrado' });

      const deposit = DepositService.findById(pixId);
      if (!deposit) return res.status(404).json({ error: 'Depósito não encontrado' });
      if (deposit.status === 'CONFIRMED') return res.json({ ok: true }); // idempotente

      const confirmed = DepositService.confirm(pixId);
      if (confirmed) {
        UserService.updateBalance(deposit.userId, deposit.amount);
        TransactionService.add(
          deposit.userId,
          'deposit',
          deposit.amount,
          `Depósito via Pix confirmado`,
          { depositId: pixId }
        );
        console.log(`✅ Depósito confirmado: ${deposit.userId} +${deposit.amount} fichas`);
      }
    }

    res.json({ ok: true });
  } catch (err) {
    console.error('Webhook error:', err);
    res.status(500).json({ error: 'Erro no webhook' });
  }
});

// POST /api/payment/deposit/check - Verificar status do depósito
router.post('/deposit/check', authMiddleware, async (req, res) => {
  try {
    const { depositId } = req.body;
    const deposit = DepositService.findById(depositId);

    if (!deposit || deposit.userId !== req.user.id) {
      return res.status(404).json({ error: 'Depósito não encontrado' });
    }

    // Verificar na Abacatepay
    const pixStatus = await abacateRequest('GET', `/pixQrCode/check?id=${depositId}`);

    if (pixStatus.data?.status === 'PAID' && deposit.status === 'PENDING') {
      const confirmed = DepositService.confirm(depositId);
      if (confirmed) {
        UserService.updateBalance(deposit.userId, deposit.amount);
        TransactionService.add(deposit.userId, 'deposit', deposit.amount, 'Depósito via Pix', { depositId });
      }
    }

    res.json({
      status: deposit.status,
      amount: deposit.amount,
    });
  } catch (err) {
    console.error('Check deposit error:', err);
    res.status(500).json({ error: 'Erro ao verificar depósito' });
  }
});

// POST /api/payment/withdraw - Solicitar saque
router.post('/withdraw', authMiddleware, rateLimit({ windowMs: 60 * 60 * 1000, max: 3 }), async (req, res) => {
  try {
    const { amount, pixKey } = req.body;
    const user = req.user;

    if (!amount || amount < MIN_WITHDRAW) {
      return res.status(400).json({ error: `Saque mínimo: ${MIN_WITHDRAW} fichas (R$${fichasToReais(MIN_WITHDRAW)})` });
    }

    if (!pixKey || pixKey.trim().length < 5) {
      return res.status(400).json({ error: 'Chave Pix inválida' });
    }

    if (user.balance < amount) {
      return res.status(400).json({ error: 'Saldo insuficiente' });
    }

    // Calcular taxa
    const fee = Math.floor(amount * WITHDRAW_FEE / 100);
    const netAmount = amount - fee;
    const netReais = parseFloat(fichasToReais(netAmount));

    // Debitar saldo ANTES de processar (previne double spend)
    UserService.updateBalance(user.id, -amount);
    TransactionService.add(user.id, 'withdraw', -amount, `Saque solicitado - taxa ${WITHDRAW_FEE}%`, { pixKey, fee });

    // Em produção: usar API da Abacatepay para enviar Pix automaticamente
    // Por ora, registra para processamento manual ou automático
    console.log(`💸 Saque solicitado: ${user.id} (${user.nick}) - ${netReais} via ${pixKey}`);

    res.json({
      success: true,
      message: `Saque de R$${netReais.toFixed(2)} solicitado com sucesso! Será processado em até 24h.`,
      net: netAmount,
      netReais,
      fee,
    });
  } catch (err) {
    console.error('Withdraw error:', err);
    res.status(500).json({ error: 'Erro ao processar saque' });
  }
});

// GET /api/payment/balance
router.get('/balance', authMiddleware, (req, res) => {
  const user = UserService.findById(req.user.id);
  res.json({
    balance: user.balance,
    balanceReais: fichasToReais(user.balance),
  });
});

// GET /api/payment/transactions
router.get('/transactions', authMiddleware, (req, res) => {
  const txs = TransactionService.getUserTransactions(req.user.id);
  res.json({ transactions: txs });
});

module.exports = router;
