// db.js - Banco de dados em memória para MVP
// Em produção na Hostinger, substituir por MySQL usando mysql2
// Exemplo de conexão MySQL:
// const mysql = require('mysql2/promise');
// const db = mysql.createPool({ host, user, password, database });

const bcrypt = require('bcryptjs');

// Simula banco de dados em memória
const DB = {
  users: new Map(),       // id -> user
  usersByEmail: new Map(), // email -> id
  usersByCPF: new Map(),   // cpf -> id
  usersByNick: new Map(),  // nick -> id
  sessions: new Map(),     // token -> userId
  transactions: [],        // array de transações
  games: new Map(),        // gameId -> game
  deposits: new Map(),     // depositId -> deposit
  withdrawals: [],         // array de saques
};

// Bots pré-cadastrados
const BOTS = [
  { id: 'bot_1', nick: 'ZéDasQuina', isBot: true, balance: 999999 },
  { id: 'bot_2', nick: 'MarcelãoX', isBot: true, balance: 999999 },
  { id: 'bot_3', nick: 'TiaBiinha', isBot: true, balance: 999999 },
  { id: 'bot_4', nick: 'PedrãoCria', isBot: true, balance: 999999 },
  { id: 'bot_5', nick: 'GabiSmart', isBot: true, balance: 999999 },
  { id: 'bot_6', nick: 'RafaZika', isBot: true, balance: 999999 },
  { id: 'bot_7', nick: 'LuMoça', isBot: true, balance: 999999 },
  { id: 'bot_8', nick: 'BrunoFoda', isBot: true, balance: 999999 },
];

BOTS.forEach(bot => DB.users.set(bot.id, bot));

const UserService = {
  async create({ nick, email, cpf, password }) {
    const id = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    const hashedPassword = await bcrypt.hash(password, 12);
    const cleanCPF = cpf.replace(/\D/g, '');
    
    const user = {
      id,
      nick,
      email: email.toLowerCase(),
      cpf: cleanCPF,
      password: hashedPassword,
      balance: 0,         // fichas
      isBot: false,
      wins: 0,
      losses: 0,
      draws: 0,
      createdAt: new Date().toISOString(),
      banned: false,
    };

    DB.users.set(id, user);
    DB.usersByEmail.set(email.toLowerCase(), id);
    DB.usersByCPF.set(cleanCPF, id);
    DB.usersByNick.set(nick.toLowerCase(), id);

    return user;
  },

  findById(id) {
    return DB.users.get(id) || null;
  },

  findByEmail(email) {
    const id = DB.usersByEmail.get(email.toLowerCase());
    return id ? DB.users.get(id) : null;
  },

  existsEmail(email) { return DB.usersByEmail.has(email.toLowerCase()); },
  existsCPF(cpf) { return DB.usersByCPF.has(cpf.replace(/\D/g, '')); },
  existsNick(nick) { return DB.usersByNick.has(nick.toLowerCase()); },

  async validatePassword(user, password) {
    return bcrypt.compare(password, user.password);
  },

  updateBalance(userId, delta) {
    const user = DB.users.get(userId);
    if (!user) return null;
    user.balance = Math.max(0, user.balance + delta);
    return user;
  },

  updateStats(userId, result) {
    const user = DB.users.get(userId);
    if (!user || user.isBot) return;
    if (result === 'win') user.wins++;
    else if (result === 'loss') user.losses++;
    else user.draws++;
  },

  safePublic(user) {
    if (!user) return null;
    const { password, cpf, email, ...pub } = user;
    return pub;
  },

  getRandomBot() {
    return BOTS[Math.floor(Math.random() * BOTS.length)];
  }
};

const TransactionService = {
  add(userId, type, amount, description, meta = {}) {
    const tx = {
      id: 'tx_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      userId,
      type,       // deposit | withdraw | bet | win | rake
      amount,
      description,
      meta,
      createdAt: new Date().toISOString(),
    };
    DB.transactions.push(tx);
    return tx;
  },

  getUserTransactions(userId, limit = 20) {
    return DB.transactions
      .filter(t => t.userId === userId)
      .slice(-limit)
      .reverse();
  }
};

const DepositService = {
  create(userId, amount, pixData) {
    const deposit = {
      id: pixData.id,
      userId,
      amount,
      status: 'PENDING',
      pixData,
      createdAt: new Date().toISOString(),
    };
    DB.deposits.set(deposit.id, deposit);
    return deposit;
  },

  findById(id) { return DB.deposits.get(id); },

  confirm(id) {
    const dep = DB.deposits.get(id);
    if (!dep || dep.status !== 'PENDING') return null;
    dep.status = 'CONFIRMED';
    dep.confirmedAt = new Date().toISOString();
    return dep;
  }
};

module.exports = { DB, UserService, TransactionService, DepositService, BOTS };
