const express = require('express');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { UserService } = require('../db');

const router = express.Router();

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Muitas tentativas. Aguarde 15 minutos.' }
});

function validateCPF(cpf) {
  cpf = cpf.replace(/\D/g, '');
  if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += parseInt(cpf[i]) * (10 - i);
  let rev = 11 - (sum % 11);
  if (rev >= 10) rev = 0;
  if (rev !== parseInt(cpf[9])) return false;
  sum = 0;
  for (let i = 0; i < 10; i++) sum += parseInt(cpf[i]) * (11 - i);
  rev = 11 - (sum % 11);
  if (rev >= 10) rev = 0;
  return rev === parseInt(cpf[10]);
}

function generateToken(userId) {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: '7d' });
}

// POST /api/auth/register
router.post('/register', authLimiter, async (req, res) => {
  try {
    const { nick, email, cpf, password } = req.body;

    if (!nick || !email || !cpf || !password) {
      return res.status(400).json({ error: 'Todos os campos são obrigatórios' });
    }

    if (nick.length < 3 || nick.length > 20) {
      return res.status(400).json({ error: 'Apelido deve ter entre 3 e 20 caracteres' });
    }

    if (!/^[a-zA-Z0-9_]+$/.test(nick)) {
      return res.status(400).json({ error: 'Apelido só pode ter letras, números e _' });
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: 'E-mail inválido' });
    }

    if (!validateCPF(cpf)) {
      return res.status(400).json({ error: 'CPF inválido' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Senha deve ter pelo menos 6 caracteres' });
    }

    if (UserService.existsEmail(email)) {
      return res.status(409).json({ error: 'E-mail já cadastrado' });
    }

    if (UserService.existsCPF(cpf)) {
      return res.status(409).json({ error: 'CPF já cadastrado' });
    }

    if (UserService.existsNick(nick)) {
      return res.status(409).json({ error: 'Apelido já em uso' });
    }

    const user = await UserService.create({ nick, email, cpf, password });
    const token = generateToken(user.id);

    res.status(201).json({
      token,
      user: UserService.safePublic(user)
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// POST /api/auth/login
router.post('/login', authLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'E-mail e senha são obrigatórios' });
    }

    const user = UserService.findByEmail(email);
    if (!user) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    if (user.banned) {
      return res.status(403).json({ error: 'Conta suspensa. Entre em contato com o suporte.' });
    }

    const valid = await UserService.validatePassword(user, password);
    if (!valid) {
      return res.status(401).json({ error: 'Credenciais inválidas' });
    }

    const token = generateToken(user.id);

    res.json({
      token,
      user: UserService.safePublic(user)
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// GET /api/auth/me
router.get('/me', require('../middleware/auth'), (req, res) => {
  res.json({ user: UserService.safePublic(req.user) });
});

module.exports = router;
