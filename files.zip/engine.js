// game/engine.js - Lógica do jogo 100% no servidor (segurança crítica)

const { v4: uuidv4 } = require('uuid');
const { UserService, TransactionService } = require('../db');

const RAKE_PERCENT = parseInt(process.env.RAKE_PERCENT || 10);

const WINNING_COMBOS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // linhas
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // colunas
  [0, 4, 8], [2, 4, 6],             // diagonais
];

function checkWinner(board) {
  for (const [a, b, c] of WINNING_COMBOS) {
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], combo: [a, b, c] };
    }
  }
  if (board.every(cell => cell !== null)) return { winner: 'draw', combo: [] };
  return null;
}

function getBotMove(board) {
  // Minimax simplificado para bot inteligente
  function minimax(b, isMax) {
    const result = checkWinner(b);
    if (result) {
      if (result.winner === 'O') return 10;
      if (result.winner === 'X') return -10;
      return 0;
    }
    const scores = [];
    for (let i = 0; i < 9; i++) {
      if (!b[i]) {
        b[i] = isMax ? 'O' : 'X';
        scores.push(minimax(b, !isMax));
        b[i] = null;
      }
    }
    return isMax ? Math.max(...scores) : Math.min(...scores);
  }

  let bestScore = -Infinity;
  let bestMove = -1;
  const available = board.map((v, i) => v === null ? i : -1).filter(i => i >= 0);

  // 70% chance de jogar ótimo, 30% de errar (para não ser impossível)
  if (Math.random() < 0.3) {
    return available[Math.floor(Math.random() * available.length)];
  }

  for (const i of available) {
    board[i] = 'O';
    const score = minimax(board, false);
    board[i] = null;
    if (score > bestScore) { bestScore = score; bestMove = i; }
  }
  return bestMove;
}

class GameRoom {
  constructor({ player1, player2, bet, isBot = false }) {
    this.id = uuidv4();
    this.board = Array(9).fill(null);
    this.player1 = player1;   // { id, nick, isBot }
    this.player2 = player2;
    this.currentTurn = player1.id; // X sempre começa
    this.bet = bet;
    this.status = 'playing'; // playing | finished
    this.winner = null;
    this.winCombo = [];
    this.isBot = isBot;
    this.createdAt = Date.now();
    this.moves = [];

    // Bloquear fichas dos jogadores
    if (!player1.isBot) UserService.updateBalance(player1.id, -bet);
    if (!player2.isBot) UserService.updateBalance(player2.id, -bet);
  }

  makeMove(playerId, position) {
    if (this.status !== 'playing') {
      return { error: 'Jogo já encerrado' };
    }

    if (this.currentTurn !== playerId) {
      return { error: 'Não é sua vez' };
    }

    if (position < 0 || position > 8 || this.board[position] !== null) {
      return { error: 'Posição inválida' };
    }

    const symbol = playerId === this.player1.id ? 'X' : 'O';
    this.board[position] = symbol;
    this.moves.push({ playerId, position, symbol });

    const result = checkWinner(this.board);
    if (result) {
      this.status = 'finished';
      this.winCombo = result.combo;

      if (result.winner === 'draw') {
        this.winner = 'draw';
        this._settleDraw();
      } else {
        const winnerId = result.winner === 'X' ? this.player1.id : this.player2.id;
        const loserId = winnerId === this.player1.id ? this.player2.id : this.player1.id;
        this.winner = winnerId;
        this._settleWin(winnerId, loserId);
      }
    } else {
      // Trocar turno
      this.currentTurn = this.currentTurn === this.player1.id ? this.player2.id : this.player1.id;
    }

    return { board: this.board, status: this.status, winner: this.winner, winCombo: this.winCombo };
  }

  _settleWin(winnerId, loserId) {
    const totalPot = this.bet * 2;
    const rake = Math.floor(totalPot * RAKE_PERCENT / 100);
    const prize = totalPot - rake;

    if (!UserService.findById(winnerId)?.isBot) {
      UserService.updateBalance(winnerId, prize);
      TransactionService.add(winnerId, 'win', prize, `Vitória no jogo - prêmio líquido`, { gameId: this.id, rake });
      UserService.updateStats(winnerId, 'win');
    }
    if (!UserService.findById(loserId)?.isBot) {
      TransactionService.add(loserId, 'bet', -this.bet, `Derrota no jogo`, { gameId: this.id });
      UserService.updateStats(loserId, 'loss');
    }

    console.log(`🏆 Game ${this.id}: winner=${winnerId} prize=${prize} rake=${rake}`);
  }

  _settleDraw() {
    // Empate: devolve fichas descontando metade do rake
    const halfRake = Math.floor(this.bet * RAKE_PERCENT / 100 / 2);
    const refund = this.bet - halfRake;

    [this.player1, this.player2].forEach(p => {
      if (!p.isBot) {
        UserService.updateBalance(p.id, refund);
        TransactionService.add(p.id, 'draw', refund - this.bet, `Empate - devolução parcial`, { gameId: this.id });
        UserService.updateStats(p.id, 'draw');
      }
    });
  }

  getBotMovePosition() {
    return getBotMove([...this.board]);
  }

  toPublic() {
    return {
      id: this.id,
      board: this.board,
      player1: { id: this.player1.id, nick: this.player1.nick, isBot: this.player1.isBot },
      player2: { id: this.player2.id, nick: this.player2.nick, isBot: this.player2.isBot },
      currentTurn: this.currentTurn,
      bet: this.bet,
      status: this.status,
      winner: this.winner,
      winCombo: this.winCombo,
    };
  }
}

module.exports = { GameRoom, checkWinner };
