# 🎮 TicTacBet — Setup Completo

## Estrutura do Projeto
```
tictacbet/
├── frontend/
│   └── index.html          ← Arquivo único do app (mobile-first)
└── backend/
    ├── package.json
    ├── .env.example        ← Copie para .env e configure
    └── src/
        ├── index.js        ← Servidor principal
        ├── db.js           ← Banco de dados em memória (MVP)
        ├── middleware/auth.js
        ├── routes/
        │   ├── auth.js     ← Login, registro
        │   └── payment.js  ← Abacatepay (depósito, saque, webhook)
        └── game/
            ├── engine.js   ← Lógica do jogo (servidor)
            └── manager.js  ← Matchmaking + WebSocket
```

---

## 🚀 Setup na Hostinger

### 1. Backend (Node.js na Hostinger)

A Hostinger suporta Node.js via **hPanel > Node.js App**

```bash
# 1. Faça upload da pasta backend via FTP ou Git
# 2. No hPanel, vá em: Websites > Gerenciar > Node.js

# Instalar dependências
npm install

# Criar arquivo .env baseado no exemplo
cp .env.example .env
# Edite o .env com suas configurações

# Iniciar o servidor
npm start
```

**Configuração no hPanel:**
- Application root: `/public_html/backend`
- Application URL: seu domínio ou subdomínio
- Startup file: `src/index.js`
- Node.js version: 18+

### 2. Frontend

Faça upload do `frontend/index.html` para `/public_html/`

**Edite a linha no início do script:**
```javascript
const API = 'https://api.seusite.com'; // URL do seu backend
```

### 3. Abacatepay

1. Acesse app.abacatepay.com
2. Vá em Configurações > API Keys
3. Gere uma nova key e copie
4. Configure no .env:
```
ABACATEPAY_API_KEY=sua_key_aqui
```

5. Configure o Webhook:
- URL: `https://api.seusite.com/api/payment/webhook`
- Evento: `pixQrCode.paid`
- Copie o Webhook Secret e coloque no .env

### 4. Variáveis de ambiente (.env)
```
PORT=3001
JWT_SECRET=string_aleatoria_longa_aqui
ABACATEPAY_API_KEY=abacatepay_live_xxx
ABACATEPAY_WEBHOOK_SECRET=whsec_xxx
FRONTEND_URL=https://seusite.com
RAKE_PERCENT=10
MIN_BET=10
MAX_BET=10000
MIN_WITHDRAW=500
WITHDRAW_FEE_PERCENT=5
```

---

## 💰 Modelo de Fichas

| Fichas | Valor em Reais |
|--------|---------------|
| 10 | R$ 1,00 |
| 50 | R$ 5,00 |
| 100 | R$ 10,00 |
| 500 | R$ 50,00 |
| 1000 | R$ 100,00 |

**Taxa da casa:** 10% de rake por partida
**Taxa de saque:** 5% sobre o valor sacado
**Saque mínimo:** 500 fichas (R$ 50,00)

---

## 🔒 Segurança implementada

- ✅ Senhas com bcrypt (salt 12)
- ✅ JWT com expiração de 7 dias
- ✅ Rate limiting em todas as rotas
- ✅ Validação de CPF no servidor
- ✅ Lógica do jogo 100% no servidor
- ✅ Verificação de assinatura do webhook
- ✅ Transações atômicas (sem double spend)
- ✅ 1 CPF = 1 conta
- ✅ Dados sensíveis nunca expostos na API

---

## 🗄️ Migração para MySQL (Produção)

O projeto usa banco em memória no MVP. Para produção com mais usuários, migre para MySQL (disponível na Hostinger):

```bash
npm install mysql2
```

Substitua o `db.js` por queries MySQL. A estrutura das tabelas:

```sql
CREATE TABLE users (
  id VARCHAR(50) PRIMARY KEY,
  nick VARCHAR(20) UNIQUE NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  cpf VARCHAR(11) UNIQUE NOT NULL,
  password VARCHAR(100) NOT NULL,
  balance INT DEFAULT 0,
  wins INT DEFAULT 0,
  losses INT DEFAULT 0,
  draws INT DEFAULT 0,
  banned BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE transactions (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  type ENUM('deposit','withdraw','win','bet','rake','draw'),
  amount INT NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE deposits (
  id VARCHAR(100) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  amount INT NOT NULL,
  status ENUM('PENDING','CONFIRMED') DEFAULT 'PENDING',
  created_at TIMESTAMP DEFAULT NOW(),
  confirmed_at TIMESTAMP NULL
);
```

---

## 🤖 Bots disponíveis

Os bots têm apelidos brasileiros comuns e jogam com inteligência minimax (70% ótimo, 30% aleatório para ser beatable):

- ZéDasQuina, MarcelãoX, TiaBiinha
- PedrãoCria, GabiSmart, RafaZika
- LuMoça, BrunoFoda

---

## 📱 Features do Frontend

- Mobile-first, funciona em qualquer celular
- PWA-ready (pode ser instalado como app)
- Dark mode com tema neon roxo
- Animações suaves no tabuleiro
- Toast notifications
- QR Code Pix com timer
- Histórico de transações
- Estatísticas do jogador
